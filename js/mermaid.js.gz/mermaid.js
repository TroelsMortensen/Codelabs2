﻿window.renderMermaid = () => {
    mermaid.init(undefined, document.querySelectorAll("pre.mermaid"));
};